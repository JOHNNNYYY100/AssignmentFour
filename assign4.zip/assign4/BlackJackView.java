package assign4;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

public class BlackJackView extends Pane{
	
	HandPane       dealerPane;
	PlayerPane     playerPane;
	Button         hitMe, stay, newGame;
	Label          message;
	BlackJackModel model;
	
	public BlackJackView(BlackJackModel model) {
		this.model = model;
		dealerPane = new HandPane("Dealer Hand");
		playerPane = new PlayerPane("Player Hand");
		
        newGame = new Button("New Deal");
        hitMe = new Button("Hit Me");
        stay = new Button("Stay");
        
       
        message = new Label("Place bets!");
        
        // you may change this to BorderPane if you like.
        // Either way, add the components to it.
        GridPane root = new GridPane();
        
        getChildren().add(root);
	}
	
	/*
	 * Write getters for 'newDeal', 'hitMe', and 'stay' button.
	 * Write getter for  'betButton' (from the playerPane class).
	 * Write getter for  'getBet()'  (from the playerPane class).
	 */
	
	
	
	// we update all fields in the view with data from the model
	public void update() {
		//update the player hand (in playerPane object), 
		//       the player bet  (in playerPane object),  
		//       the player cash (in playerPane object), 
		//       the dealer hand (in dealerPane object),
		//       the message label.
		
		// All of this information is available by calling the appropriate model method. 

		
	}

}
