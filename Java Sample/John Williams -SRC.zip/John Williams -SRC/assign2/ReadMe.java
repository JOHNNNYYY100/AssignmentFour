/*
//There is the big error of me not getting a output.
//Or more specifically  unable to figure how to  assign  variables to knownSongs array in the learn song method
//I believe the logic is correct for most of my methods
//Its just the setting up the KnownSong array is incorrect correct and affects the output.
//Since variables are not being assigned to the knownSong array it cannot be equal to song and print

Question One
//Done

Question Two
//Done

Question Three
//Done

Question Four
//Done

Question Five
//There must be an error that is preventing variable from being assigned to knownSong

Question Six
//Done

Question Seven
//Done

Question Eight
//Done

Question Nine
//Done

Question Ten
//done

Question Eleven
//There might be a mistake in my array it was hard to check when you cant test your code

Question Twelve
//Done

Question Thirteen
//Done


*/

