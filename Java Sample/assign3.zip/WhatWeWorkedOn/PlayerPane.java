package assign3;

public class PlayerPane extends HandPane{
    public PlayerPane(String name) {
        super(name);
    }


}
