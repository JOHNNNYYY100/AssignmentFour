package FxTesting;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;


import java.util.function.DoubleBinaryOperator;


public class MyApplication extends Application{

    public void start(Stage primaryStage){

        Pane aPane=new Pane();

        //Player Hand

        Label PB1 =new Label("Player 1 Hand");
        PB1.relocate(1,60);
        PB1.setPrefSize(100,30);
        PB1.setFont(Font.font("Impact",11));
        PB1.setStyle("-fx-font: 11 Impact; -fx-base: rgb(170,0,0); -fx-text-fill: rgb(0 ,204,0);");
        PB1.setAlignment(Pos.CENTER);




        Label PB2=new Label("Total");
        PB2.relocate(1,90);
        PB2.setPrefSize(100,30);
        PB2.setFont(Font.font("Impact",11));
        PB2.setStyle("-fx-font: 11 Impact; -fx-base: rgb(170,0,0); -fx-text-fill: rgb(0 ,204,0);");
        PB2.setAlignment(Pos.CENTER);




        TextField PT1=new TextField("Player Card");
        PT1.relocate(100,60);
        PT1.setPrefSize(200,30);
        PT1.setStyle("-fx-font: 13 impact; -fx-base: rgb(0,204,0); -fx-text-fill: rgb(170,0,0);");



        TextField PT2=new TextField("Player's Total");
        PT2.relocate(100,90);
        PT2.setPrefSize(200,30);
        PT2.setStyle("-fx-font: 13 impact; -fx-base: rgb(0,204,0); -fx-text-fill: rgb(170,0,0);");

        //Dealer Hand

        Label DB1= new Label("Dealer Hand");
        DB1.relocate(1,1);
        DB1.setPrefSize(100,30);
        DB1.setStyle("-fx-font: 11 Impact; -fx-base: rgb(170,0,0); -fx-text-fill: rgb(0 ,204,0);");
        DB1.setAlignment(Pos.CENTER);

        Label DB2=new Label("Total");
        DB2.relocate(1,30);
        DB2.setPrefSize(100,30);
        DB2.setStyle("-fx-font: 11 Impact; -fx-base: rgb(170,0,0); -fx-text-fill: rgb(0 ,204,0);");
        DB2.setAlignment(Pos.CENTER);


        TextField DT1=new TextField("Dealer's Card");
        DT1.relocate(100,1);
        DT1.setPrefSize(200,30);
        DT1.setStyle("-fx-font: 13 impact; -fx-base: rgb(0,204,0); -fx-text-fill: rgb(170,0,0);");

        TextField DT2= new TextField("Dealer's Total");
        DT2.relocate(100,30);
        DT2.setPrefSize(200,30);
        DT2.setStyle("-fx-font: 13 impact; -fx-base: rgb(0,204,0); -fx-text-fill: rgb(170,0,0);");


        //Current Bet

        Label L1=new Label("Current Bet");
        L1.relocate(1,120);
        L1.setPrefSize(100,30);
        L1.setStyle("-fx-font: 11 Impact; -fx-base: rgb(170,0,0); -fx-text-fill: rgb(0 ,204,0);");
        L1.setAlignment(Pos.CENTER);

        TextField TL1 =new TextField("Current Bet");
        TL1.relocate(100,120);
        TL1.setPrefSize(200,30);
        TL1.setStyle("-fx-font: 13 impact; -fx-base: rgb(0,204,0); -fx-text-fill: rgb(170,0,0);");

        //Place Bet
        Button PBP1= new Button("Place bet");//PBP= "Place Player Bet"
        PBP1.relocate(1,150);
        PBP1.setPrefSize(100,30);
        PBP1.setStyle("-fx-font: 11 Impact; -fx-base: rgb(255,0,127); -fx-text-fill: rgb(0,0,0);"); // I made te base yellow to bring attention to the betting


        TextField TBPB1= new TextField("Place a Bet");
        TBPB1.relocate(100,150);
        TBPB1.setPrefSize(200,30);
        TBPB1.setStyle("-fx-font: 13 impact; -fx-base: rgb(0,204,0); -fx-text-fill: rgb(170,0,0);");

        //Deal Card
        Button DB= new Button("Deal Card"); //DB= Deal and Button
        DB.relocate(1,180);
        DB.setPrefSize(150,30);
        DB.setStyle("-fx-font: 11 Impact; -fx-base: rgb(170,0,0); -fx-text-fill: rgb(0 ,204,0);");

        //New Game
        Button BNG=new Button("New Game");//"BNG"= New Game "Button"
        BNG.relocate(150,180);
        BNG.setPrefSize(150,30);
        BNG.setStyle("-fx-font: 11 Impact; -fx-base: rgb(170,0,0); -fx-text-fill: rgb(0 ,204,0);");
















        primaryStage.setTitle("Black Jack"); //Title
        aPane.getChildren().addAll(PB1,PB2,PT1,PT2); //Player variables
        aPane.getChildren().addAll(DB1,DB2,DT1,DT2); // Dealer variables
        aPane.getChildren().addAll(L1,TL1); //Current Bet
        aPane.getChildren().addAll(TBPB1,PBP1); //place Bet
        aPane.getChildren().add(DB); //Deal Card
        aPane.getChildren().addAll(BNG); //New Game
        aPane.setStyle("-fx-background-Color: Black");//Background Color
        primaryStage.setScene(new Scene(aPane,300,210)); //Dimension of window
        primaryStage.show(); //To view





    }

    public static void main(String args[]){
        launch(args);
    }
}
