package assign3;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class BlackJackApplication extends Application{
	
	/*
	 These are the 'model' elements.
	 */
	Hand dealerHand, playerHand;
	Deck deck;

	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("BlackJack!");

        //TODO: You should have two types of Panes that you have made, one
		//TODO: for the dealer and one for the player. You want it to display their
		//TODO: respective hands


        //TODO: Make a dealCard button that, when clicked, deals one card to the dealer and
		//TODO: one to the player. Don't forget to update the view.

        
        //TODO: Make a newGame Button that, when clicked, resets the player and
        //TODO: dealer hands to empty hands and updates the view.
        
        
        FlowPane aPane = new FlowPane();
        //TODO: add elements to the FlowPane in the order you wish them to appear
		//TODO: feel free to use a different layout if you wish.
        
    
        primaryStage.setScene(new Scene(aPane, 400, 400));
        primaryStage.show();
		
	}
	
	public void update() {
		//TODO: update the GUI. Presumably the dealer's and player's hands have
		//TODO: changed since this was last called.
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}

}
